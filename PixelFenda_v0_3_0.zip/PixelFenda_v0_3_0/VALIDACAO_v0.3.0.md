# Validação — PixelFenda v0.3.0

## Estado da build

Build de desenvolvimento validada em bancada local para entrega ao usuário. A validação física da rota OpenGL/NVENC em RTX 4060 deve ser repetida no computador do usuário com `teste_v030.py`, porque o ambiente desta bancada não possui contexto OpenGL/NVENC NVIDIA.

## Testes executados

### Compilação
- `pixelfenda.py`: OK
- todos os módulos em `pixelfenda/*.py`: OK
- `teste_v030.py`: OK

### Modelos/projetos
- `LayerSpec`: serialização e normalização: OK
- `ProjectDocument`: save/load JSON: OK
- Projeto com 4 camadas: roundtrip OK

### Layer Stack
- efeito + efeito + filtro + LUT: OK
- blend Screen: OK
- blend Normal: OK
- modulação Beat: OK
- modulação Motion: OK
- Auto Scene Mutator: OK
- estado VRAM por camada: OK em CPU

### Blend modes
Todos retornaram imagem `uint8` válida:
- Normal
- Screen
- Multiply
- Add
- Difference
- Overlay
- Soft Light
- Lighten
- Darken

### Efeitos
- 25/25 presets declarados passaram por processamento CPU/fallback.
- Novos presets: Cyber Wire, Liquid Chrome, PSX Dither, Gothic Halo, Signal Grid.

### Filtros
- 19/19 filtros visuais passaram por processamento CPU/fallback.

### LUT
- parser `.cube`: OK
- `LUT_3D_SIZE 17`: OK
- trilinear interpolation: OK
- Cobalt Noir: OK
- Amber Crypt: OK
- Chrome Ice: OK

### Detecção de cena
- detector HSV: OK
- corte sintético preto -> branco: detectado
- vídeo sintético de 60 quadros: corte no frame 30 detectado com score ~0.617
- CLI `--analyze-scenes`: OK

### Render real em bancada
Entrada sintética:
- 320×240
- 30 fps
- 60 quadros

Pilha:
1. Cyber Wire — motion modulated
2. Cold Archive
3. LUT Amber Crypt

Configuração:
- CPU
- libx264
- silent
- Auto Scene Mutator

Resultado:
- 60/60 quadros: OK
- arquivo MP4 final: OK
- duas cenas registradas: OK

### CLI
- `--help`: OK
- efeito + filtro: OK
- render parcial com `--max-seconds`: OK
- JSON de resultado: OK
- análise de cenas em JSON: OK

### GPU/NVENC
No ambiente desta bancada:
- ModernGL standalone: indisponível
- NVENC: indisponível
- fallback CPU: OK

Isso **não é falha da build**. Na v0.2.1, o computador do usuário já validou:
- NVIDIA GeForce RTX 4060 / ModernGL: OK
- H.264 NVENC: OK
- HEVC NVENC: OK
- AV1 NVENC: OK

A v0.3.0 adiciona novos shaders e composição multi-layer; portanto a validação final esperada no mesmo hardware é executar:

```powershell
python .\teste_v030.py
```

O teste de GPU da v0.3 contém em uma única pilha:
- Cyber Wire
- Liquid Chrome
- PSX Dither
- Gothic Halo
- Signal Grid
- Spectral Echo
- Vintage 70

Isso valida novos shaders, feedback e filtro no pipeline em camadas.
